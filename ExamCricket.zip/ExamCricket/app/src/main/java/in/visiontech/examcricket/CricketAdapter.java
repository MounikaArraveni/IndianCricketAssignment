package in.visiontech.examcricket;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CricketAdapter extends RecyclerView.Adapter<CricketAdapter.MyViewHolder> {
    Context context;
    ArrayList<Cricket>cricketArrayList;
    int currentposition;
    DatabaseReference databaseReference;
    String Dname,Drole;


    public CricketAdapter(Context context, ArrayList<Cricket> cricketArrayList) {
        this.context = context;
        this.cricketArrayList = cricketArrayList;
    }

    @NonNull
    @Override
    public CricketAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.card_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CricketAdapter.MyViewHolder holder, int position) {
         Cricket cricket=cricketArrayList.get(position);
         holder.name.setText(cricket.getName());
         holder.role.setText(cricket.getRole());
         holder.img.setImageResource(cricket.getImg());
         if(cricket.getRole().equals("All-Rounder")){
             holder.img.setImageResource(R.drawable.allrounder);
         }
         if(cricket.getRole().equals("Bowler")){
             holder.img.setImageResource(R.drawable.bowlerr);
         }
        if(cricket.getRole().equals("Batter")){
            holder.img.setImageResource(R.drawable.bat);
        }

         holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
             @Override
             public boolean onLongClick(View v) {
                 PopupMenu popupMenu=new PopupMenu(context,v);
                 currentposition=holder.getAdapterPosition();
                 popupMenu.getMenuInflater().inflate(R.menu.popupmenu,popupMenu.getMenu());
                  popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                      @Override
                      public boolean onMenuItemClick(MenuItem item) {
                          if(item.getItemId()==R.id.delete_id){
                              deleteitem();
                          }
                          else if(item.getItemId()==R.id.upadate_id){
                              updateitem();
                          }

                          return true;
                      }

                      private void updateitem() {

                          Dialog dialog= new Dialog(context);
                          dialog.setContentView(R.layout.update_item);
                          dialog.show();
                          EditText tname=dialog.findViewById(R.id.Dname_id);
                          EditText trole=dialog.findViewById(R.id.Drole_id);
                          Button tbtn=dialog.findViewById(R.id.Dbtn_id);
                          tname.setText(cricketArrayList.get(currentposition).getName());
                          trole.setText(cricketArrayList.get(currentposition).getRole());
                          tbtn.setOnClickListener(new View.OnClickListener() {
                              @Override
                              public void onClick(View v) {
                                  Dname=tname.getText().toString();
                                  Drole=trole.getText().toString();
                                  Cricket cricket=cricketArrayList.get(currentposition);
                                  cricket.setName(Dname);
                                  cricket.setRole(Drole);



                              }
                          });

                      }

                      private void deleteitem() {
                          Cricket cricket1=cricketArrayList.get(currentposition);
                          databaseReference=FirebaseDatabase.getInstance().getReference("Cricketers");
                          Query query=databaseReference.orderByChild("name").equalTo(cricket1.getName());
                          query.addValueEventListener(new ValueEventListener() {
                              @Override
                              public void onDataChange(@NonNull DataSnapshot snapshot) {
                                  for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                                     dataSnapshot.getRef().removeValue();
                                      notifyDataSetChanged();
                                  }
                              }

                              @Override
                              public void onCancelled(@NonNull DatabaseError error) {

                              }
                          });
                      }
                  });
                  popupMenu.show();
                  return true;
             }
         });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(context,Selecteditem.class);
                in.putExtra("cricketer",cricket);
                in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(in);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cricketArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name,role;
        ImageView img;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.seletor_name);
            role=itemView.findViewById(R.id.role_id);
            img=itemView.findViewById(R.id.img_id);
        }
    }
}
