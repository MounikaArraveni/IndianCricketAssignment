package in.visiontech.examcricket;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
RecyclerView recyclerView;
ArrayList<Cricket> cricketArrayList;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
String spinnerplay,spinnerrol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycler_id);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference("Cricketers");
        loadData();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionsmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    if(item.getItemId()==R.id.add_btn){
        Dialog dialog=new Dialog(this);
        dialog.setContentView(R.layout.add_player);
        dialog.show();
        Spinner spinnerplsyer=dialog.findViewById(R.id.namespiiner_id);
        Spinner spinnerrole=dialog.findViewById(R.id.eolespinner_id);
        Button button=dialog.findViewById(R.id.addbutton_id);
        ArrayAdapter<CharSequence> arrayAdapter=ArrayAdapter.createFromResource(getApplicationContext(),R.array.SelectName, android.R.layout.simple_spinner_dropdown_item);
        spinnerplsyer.setAdapter(arrayAdapter);
        ArrayAdapter<CharSequence> arrayAdapter1=ArrayAdapter.createFromResource(getApplicationContext(),R.array.SeleceRole, android.R.layout.simple_spinner_dropdown_item);
        spinnerrole.setAdapter(arrayAdapter1);
        spinnerplsyer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              spinnerplay=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerrole.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinnerrol=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addDataToFireBase(spinnerplay,spinnerrol);
                 dialog.dismiss();
                 loadData();
            }



            private void addDataToFireBase(String spinnerplay, String spinnerrol) {
                Cricket cricket=new Cricket(spinnerplay,spinnerrol);
                databaseReference.push().setValue(cricket);

            }


        });

    }
        return super.onOptionsItemSelected(item);
    }

    private void loadData() {
            databaseReference=FirebaseDatabase.getInstance().getReference("Cricketers");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    cricketArrayList=new ArrayList<>();
                    for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                        Cricket crickets=dataSnapshot.getValue(Cricket.class);
                        cricketArrayList.add(crickets);

                    }
                    CricketAdapter cricketAdapter=new CricketAdapter(getApplicationContext(),cricketArrayList);
                    recyclerView.setAdapter(cricketAdapter);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
    }
}