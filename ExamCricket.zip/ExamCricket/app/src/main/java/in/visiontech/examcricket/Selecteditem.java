package in.visiontech.examcricket;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Selecteditem extends AppCompatActivity {
TextView txt1,txt2;
ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecteditem);
        txt1=findViewById(R.id.Sname_id);
        txt2=findViewById(R.id.Srole_id);
        imageView=findViewById(R.id.imgview_id);
        Intent in=getIntent();
        Cricket cricket=(Cricket) in.getSerializableExtra("cricketer");
       txt1.setText(cricket.getName());
       txt2.setText(cricket.getRole());
       imageView.setImageResource(cricket.getImg());
        if(cricket.getRole().equals("All-Rounder")){
            imageView.setImageResource(R.drawable.allrounder);
        }
        if(cricket.getRole().equals("Bowler")){
            imageView.setImageResource(R.drawable.bowlerr);
        }
        if(cricket.getRole().equals("Batter")){
            imageView.setImageResource(R.drawable.bat);
        }
    }

}