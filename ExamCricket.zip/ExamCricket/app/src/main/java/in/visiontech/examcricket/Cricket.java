package in.visiontech.examcricket;

import java.io.Serializable;

public class Cricket implements Serializable {
    String name,role;
    int img;

    public Cricket(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public Cricket(String name, String role) {
        this.name = name;
        this.role = role;
    }


    public Cricket() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
